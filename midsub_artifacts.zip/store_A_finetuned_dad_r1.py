from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional
from abc import ABC, abstractmethod

# --- Value Objects (Fixing C2: Primitive Obsession) ---

@dataclass(frozen=True)
class Email:
    value: str
    def __post_init__(self):
        if "@" not in self.value:
            raise ValueError("Invalid email format")

@dataclass(frozen=True)
class PhoneNumber:
    value: str
    def __post_init__(self):
        if len(self.value) < 10:
            raise ValueError("Invalid phone number")

# --- Domain Models (Fixing D1: Data Class) ---

class CustomerRecord:
    def __init__(self, id: int, name: str, address: str):
        self.id = id
        self.name = name
        self.address = address
        self.status = "active"
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.notes: List[str] = []

    def add_note(self, note: str):
        self.notes.append(note)
        self.updated_at = datetime.now()

    def deactivate(self):
        self.status = "inactive"
        self.updated_at = datetime.now()

# --- Services ---

class DiscountService:
    def apply_discount(self, price: float) -> float:
        return price * 0.9  # Example logic

class PricingService:
    def __init__(self, discount_service: DiscountService):
        self.discount_service = discount_service

    def price_item(self, base_price: float) -> float:
        return self.discount_service.apply_discount(base_price)

class CartService:
    def __init__(self, pricing_service: PricingService):
        self.pricing_service = pricing_service
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def get_total(self) -> float:
        return sum(self.pricing_service.price_item(i.price) for i in self.items)

# --- Payment Gateway (Fixing C1: Long Method) ---

class PaymentGateway:
    def __init__(self, email: Email, phone: PhoneNumber, tax_rate: float):
        self.email = email
        self.phone = phone
        self.tax_rate = tax_rate

    def process_payment(self, card_details: dict, amount: float):
        # Logic to talk to external API
        print(f"Processing {amount} for {self.email.value}")
        return True

    def notify_payment(self):
        print(f"Sending notification to {self.phone.value}")

    def validate_and_charge_and_notify_payment(self, card_details: dict, amount: float):
        """Refactored to delegate to single-purpose methods."""
        if self.process_payment(card_details, amount):
            self.notify_payment()

# --- Store Manager ---

class StoreManager:
    def __init__(self, cart: CartService, payment: PaymentGateway):
        self.cart = cart
        self.payment = payment

    def create_order(self):
        total = self.cart.get_total()
        print(f"Order created with total: {total}")

    def validate_payment(self, card_details: dict):
        amount = self.cart.get_total()
        self.payment.validate_and_charge_and_notify_payment(card_details, amount)