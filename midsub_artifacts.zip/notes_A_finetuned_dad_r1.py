from typing import List, Optional
from datetime import datetime

class Note:
    """
    Represents a single note.
    Separates data storage logic from the domain model.
    """
    def __init__(self, title: str, body: str):
        self.title = title
        self.body = body
        self.created_at = datetime.now()

    def __repr__(self) -> str:
        return f"Note(title='{self.title}')"

class Notebook:
    """
    Manages a collection of notes.
    Adheres to Single Responsibility Principle by handling 
    collection logic separately from the Note entity.
    """
    def __init__(self):
        self._notes: List[Note] = []

    def add_note(self, note: Note) -> None:
        if note not in self._notes:
            self._notes.append(note)

    def remove_note(self, note: Note) -> None:
        if note in self._notes:
            self._notes.remove(note)

    def search(self, query: str) -> List[Note]:
        """
        Searches notes by title or body content.
        """
        query = query.lower()
        return [
            note for note in self._notes 
            if query in note.title.lower() or query in note.body.lower()
        ]

    @property
    def notes(self) -> List[Note]:
        return list(self._notes)

# Example Usage:
if __name__ == "__main__":
    notebook = Notebook()
    
    # Create notes
    note1 = Note("Shopping List", "Milk, Bread, Eggs")
    note2 = Note("Work", "Finish the Python project")
    
    # Save (Add) to notebook
    notebook.add_note(note1)
    notebook.add_note(note2)
    
    # Search
    results = notebook.search("Python")
    print(f"Search results: {results}")
    
    # Delete
    notebook.remove_note(note1)
    print(f"Notes remaining: {notebook.notes}")