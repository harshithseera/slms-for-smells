# Design Advisory Document
Source: test_diagram.mmd
Findings: 5 design, 18 code (predicted from the diagram; treat as suspected smells)

| ID | Smell | Location | Severity | Explanation | Suggested fix |
|----|-------|----------|----------|-------------|---------------|
| D1 | Cyclic Dependency | CartService | medium | A dependency cycle among two or more classes | Introduce an interface or mediator; invert one dependency (DIP); extract shared code |
| D2 | Cyclic Dependency | DiscountService | medium | A dependency cycle among two or more classes | Introduce an interface or mediator; invert one dependency (DIP); extract shared code |
| D3 | Cyclic Dependency | PricingService | medium | A dependency cycle among two or more classes | Introduce an interface or mediator; invert one dependency (DIP); extract shared code |
| D4 | God Class | StoreManager | medium | One class has too many methods (12+ in training) and too many outgoing dependencies (4+) | Split by responsibility (Extract Class); move behaviour next to the data it uses |
| D5 | Wide Hierarchy | Notification | medium | A parent class with 8 or more direct subclasses | Group subclasses under intermediate abstractions, or use Strategy/composition |
| C1 | Long Method | InvoiceService.generateReportAndSendEmailAndLogAction | medium | Method name implies multiple responsibilities. | Split into single-purpose methods; extract helpers |
| C2 | Long Method | PaymentGateway.validateAndChargeAndNotifyPayment | medium | Method name implies multiple responsibilities. | Split into single-purpose methods; extract helpers |
| C3 | Long Parameter List | PaymentGateway.processPayment | medium | Method has more than 5 parameters. | Introduce a parameter object; group related arguments into a class |
| C4 | Duplicate Code | PaymentGateway.validateAndChargeAndNotifyPayment | low | [untrained probe] Method name implies multiple responsibilities. | Extract the shared members into a common base class, mixin, or utility |
| C5 | Magic Number Risk | InvoiceService.discountPercentage | low | Business logic values should be dedicated types, not raw numbers. | Use named constants, configuration, or a dedicated type |
| C6 | Magic Number Risk | PaymentGateway.taxRate | low | Business logic values should be dedicated types, not raw numbers. | Use named constants, configuration, or a dedicated type |
| C7 | Primitive Obsession | CustomerProfile.city | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C8 | Primitive Obsession | CustomerProfile.country | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C9 | Primitive Obsession | CustomerProfile.firstName | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C10 | Primitive Obsession | CustomerProfile.lastName | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C11 | Primitive Obsession | CustomerProfile.preferredLanguage | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C12 | Primitive Obsession | CustomerProfile.street | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C13 | Primitive Obsession | InvoiceService.city | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C14 | Primitive Obsession | InvoiceService.country | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C15 | Primitive Obsession | InvoiceService.street | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C16 | Primitive Obsession | InvoiceService.zipCode | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C17 | Primitive Obsession | PaymentGateway.email | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |
| C18 | Primitive Obsession | PaymentGateway.phone | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |

## Limitations
- The detector was fine-tuned on synthetic diagrams whose labels come from metric thresholds (method counts, dependency counts, hierarchy depth). Treat findings as flags to check, not ground truth.
- Severity is the model's own estimate and is the least reliable output.
- Untrained smells are a generalization probe. Several of them (Feature Envy, Refused Bequest, Divergent Change, Shotgun Surgery) depend on method bodies or change history that a class diagram does not show, so expect low precision and treat them as hints only.
- Large diagrams may exceed the 3072-token context window; split them if so.

- Training labels come from string rules (comma counts, the word "And" in a method name, specific attribute names), so the model has probably learned those rules. Real diagrams with different naming may be missed or misflagged.
- Findings are predictions from signatures only. Confirm them against the generated code with an independent tool.
- Duplicate Code is untrained and needs comparison across classes, which the model sees only within one chunk of the diagram. Treat it as a hint.