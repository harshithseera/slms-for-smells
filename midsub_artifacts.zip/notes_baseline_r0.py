from typing import List

class Note:
    def __init__(self, title: str, body: str):
        self.title = title
        self.body = body

    def save(self):
        """Simulates saving the note to a persistent storage."""
        print(f"Note '{self.title}' saved.")

    def delete(self):
        """Simulates deleting the note from persistent storage."""
        print(f"Note '{self.title}' deleted.")

    def __repr__(self):
        return f"Note(title='{self.title}', body='{self.body}')"


class Notebook:
    def __init__(self):
        self.notes: List[Note] = []

    def add_note(self, note: Note):
        """Adds a note to the notebook and saves it."""
        self.notes.append(note)
        note.save()

    def remove_note(self, note: Note):
        """Removes a note from the notebook and deletes it."""
        if note in self.notes:
            self.notes.remove(note)
            note.delete()
        else:
            print("Note not found in notebook.")

    def search(self, query: str) -> List[Note]:
        """Searches for notes containing the query string in title or body."""
        results = [
            note for note in self.notes 
            if query.lower() in note.title.lower() or query.lower() in note.body.lower()
        ]
        return results