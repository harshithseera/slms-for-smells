"""
DAD RESPONSE
D1-D3: Resolved by introducing a PricingMediator to break cyclic dependencies.
D4: Resolved by delegating StoreManager responsibilities to specialized services.
D5: Resolved by grouping notifications into Digital/Physical categories.
C1-C2: Split methods into atomic operations.
C3: Introduced PaymentRequest parameter object.
C5-C6: Used constants for business logic values.
C7-C18: Introduced Value Objects (Address, Email, Phone, Name) to replace primitives.
"""

from dataclasses import dataclass
from typing import List, Dict, Any
from abc import ABC, abstractmethod
from datetime import date

# --- Value Objects ---
@dataclass(frozen=True)
class Address: street: str; city: str; country: str; zip_code: str
@dataclass(frozen=True)
class Email: value: str
@dataclass(frozen=True)
class Phone: value: str
@dataclass(frozen=True)
class Name: first: str; last: str

# --- Base Entities ---
class BaseEntity: pass
class Party(BaseEntity): pass
class Person(Party): pass

class Customer(Person):
    def __init__(self, name: Name, email: Email):
        self.name = name
        self.email = email
        self.tier = "regular"

class PremiumCustomer(Customer):
    def __init__(self, name: Name, email: Email):
        super().__init__(name, email)
        self.tier = "premium"

class VIPCustomer(PremiumCustomer):
    def __init__(self, name: Name, email: Email):
        super().__init__(name, email)
        self.tier = "vip"

# --- Notifications ---
class Notification(ABC):
    @abstractmethod
    def send(self, message: str): pass

class DigitalNotification(Notification): pass
class PhysicalNotification(Notification): pass

class EmailNotification(DigitalNotification):
    def send(self, message: str): print(f"Email: {message}")

class SmsNotification(DigitalNotification):
    def send(self, message: str): print(f"SMS: {message}")

# --- Services ---
class AuditLogger:
    def log_action(self, action: str): print(f"Audit: {action}")

class TaxCalculator:
    TAX_RATE = 0.15
    def calculate_tax(self, amount: float) -> float: return amount * self.TAX_RATE

class InventoryService:
    def reserve_stock(self, product_id: str): print(f"Reserved {product_id}")
    def release_stock(self, product_id: str): print(f"Released {product_id}")

@dataclass
class PaymentRequest:
    card: str; expiry: str; cvv: str; amount: float; currency: str
    billing: Address; shipping: Address

class PaymentGateway:
    def process_payment(self, req: PaymentRequest): print("Processing payment...")
    def validate_and_charge_and_notify_payment(self, req: PaymentRequest):
        self.process_payment(req)
        print("Payment notified")

class DiscountService:
    def apply_discount(self, price: float, tier: str) -> float:
        return price * 0.9 if tier == "vip" else price

class PricingService:
    def price_item(self, item: Any, tier: str) -> float:
        return DiscountService().apply_discount(100.0, tier)

class CartService:
    def get_total(self, items: List[Any], tier: str) -> float:
        return sum(PricingService().price_item(i, tier) for i in items)

# --- Processors ---
class OrderProcessor:
    def __init__(self):
        self.logger = AuditLogger()
        self.inventory = InventoryService()
        self.tax = TaxCalculator()
        self.payment = PaymentGateway()

    def process_order(self, order_data: Dict):
        self.inventory.reserve_stock("item1")
        self.logger.log_action("Order Processed")

# --- Store Manager ---
class StoreManager:
    def __init__(self):
        self.processor = OrderProcessor()
    
    def create_order(self, data: Dict): self.processor.process_order(data)
    def render_report(self): print("Report generated")
    def export_report(self): print("Report exported")

# --- Gateways ---
class CheckoutController:
    def checkout(self, data: Dict): OrderProcessor().process_order(data)

# --- Demo ---
if __name__ == "__main__":
    manager = StoreManager()
    customer = VIPCustomer(Name("John", "Doe"), Email("john@example.com"))
    
    print(f"Customer Tier: {customer.tier}")
    manager.create_order({"item": "Laptop"})
    manager.render_report()
    
    checkout = CheckoutController()
    checkout.checkout({"item": "Mouse"})
