from abc import ABC
from datetime import date
from typing import List, Optional
from dataclasses import dataclass
from enum import Enum

# --- Constants and Configuration ---
DEFAULT_MAX_RETRY_COUNT: int = 3

# --- Domain Models ---
class Item:
    def __init__(self, id: int, title: str):
        self.id = id
        self.title = title

class Media(Item):
    def __init__(self, id: int, title: str, length: int):
        super().__init__(id, title)
        self.length = length

class Book(Media):
    def __init__(self, id: int, title: str, length: int, isbn: str):
        super().__init__(id, title, length)
        self.isbn = isbn

class Novel(Book):
    def __init__(self, id: int, title: str, length: int, isbn: str, genre: str):
        super().__init__(id, title, length, isbn)
        self.genre = genre

class Paperback(Novel):
    def __init__(self, id: int, title: str, length: int, isbn: str, genre: str, pages: int):
        super().__init__(id, title, length, isbn, genre)
        self.pages = pages

# --- Repositories and Services (Interfaces/Stubs) ---
class BookRepo: pass
class MemberRepo: pass
class LoanRepo: pass
class FineCalculator: pass
class Mailer: pass

# --- Core Logic ---
class CatalogHub:
    def __init__(self, book_repo: BookRepo, member_repo: MemberRepo, 
                 loan_repo: LoanRepo, fine_calc: FineCalculator, mailer: Mailer):
        self.book_repo = book_repo
        self.member_repo = member_repo
        self.loan_repo = loan_repo
        self.fine_calc = fine_calc
        self.mailer = mailer

    def search_catalog(self, query: str): pass
    def reserve_book(self, member_id: int, book_id: int): pass

class LoanDesk:
    def __init__(self, zip_code: str, max_retry_count: int = DEFAULT_MAX_RETRY_COUNT):
        self.zip_code = zip_code
        self.max_retry_count = max_retry_count

    def register_loan(self, member_id: int, book_id: int, location: str, 
                      start_date: date, end_date: date, is_extended: bool):
        """Registers a loan with the configured retry policy."""
        # Implementation logic using self.max_retry_count
        pass

# --- Access Points ---
class Kiosk:
    def __init__(self, hub: CatalogHub): self.hub = hub

class MobileApp:
    def __init__(self, hub: CatalogHub): self.hub = hub

class WebPortal:
    def __init__(self, hub: CatalogHub): self.hub = hub

class Scanner:
    def __init__(self, hub: CatalogHub): self.hub = hub

class ReportJob:
    def __init__(self, hub: CatalogHub): self.hub = hub