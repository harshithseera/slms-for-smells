|                                  |   baseline |   with_dad |
|:---------------------------------|-----------:|-----------:|
| syntax_ok                        |       True |       True |
| lines                            |        144 |        132 |
| classes                          |         30 |         26 |
| max_methods_in_a_class           |          5 |          4 |
| max_params_in_a_method           |          4 |          2 |
| methods_with_>5_params           |          0 |          0 |
| methods_>30_lines                |          0 |          0 |
| magic_number_literals            |          3 |          2 |
| raw_str_email/phone/zip/currency |          0 |          2 |
| classes_in_dependency_cycles     |          0 |          0 |
| max_inheritance_depth            |          5 |          5 |