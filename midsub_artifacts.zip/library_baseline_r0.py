from abc import ABC
from datetime import date, datetime
from typing import List, Optional

# --- Domain Models ---

class Item:
    def __init__(self, id: int, title: str):
        self.id = id
        self.title = title

class Media(Item):
    def __init__(self, id: int, title: str, length: int):
        super().__init__(id, title)
        self.length = length

class Book(Media):
    def __init__(self, id: int, title: str, length: int, isbn: str):
        super().__init__(id, title, length)
        self.isbn = isbn

class Novel(Book):
    def __init__(self, id: int, title: str, length: int, isbn: str, genre: str):
        super().__init__(id, title, length, isbn)
        self.genre = genre

class Paperback(Novel):
    def __init__(self, id: int, title: str, length: int, isbn: str, genre: str, pages: int):
        super().__init__(id, title, length, isbn, genre)
        self.pages = pages

# --- Repositories (Mock implementations) ---

class BookRepo:
    def find_by_query(self, query: str): return []

class MemberRepo:
    def get_member(self, member_id: int): return None

class LoanRepo:
    def save_loan(self, loan_data: dict): pass

class FineCalculator:
    def calculate(self, due_date: date, return_date: date) -> float: return 0.0

class Mailer:
    def send(self, recipient: str, message: str): pass

# --- Core Logic ---

class CatalogHub:
    def __init__(self, book_repo: BookRepo, member_repo: MemberRepo, 
                 loan_repo: LoanRepo, fine_calc: FineCalculator, mailer: Mailer):
        self.book_repo = book_repo
        self.member_repo = member_repo
        self.loan_repo = loan_repo
        self.fine_calc = fine_calc
        self.mailer = mailer

    def search_catalog(self, query: str):
        return self.book_repo.find_by_query(query)

    def reserve_book(self, member_id: int, book_id: int):
        pass

# --- Interfaces / Clients ---

class Kiosk:
    def __init__(self, hub: CatalogHub): self.hub = hub

class MobileApp:
    def __init__(self, hub: CatalogHub): self.hub = hub

class WebPortal:
    def __init__(self, hub: CatalogHub): self.hub = hub

class Scanner:
    def __init__(self, hub: CatalogHub): self.hub = hub

class ReportJob:
    def __init__(self, hub: CatalogHub): self.hub = hub

class LoanDesk:
    def __init__(self, zip_code: str, max_retry_count: int):
        self.zip_code = zip_code
        self.max_retry_count = max_retry_count

    def register_loan(self, a: int, b: int, c: str, d: date, e: date, f: bool):
        # Implementation logic for registering a loan
        pass