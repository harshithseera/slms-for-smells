from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional
from abc import ABC, abstractmethod

# --- Value Objects (Addressing C2: Primitive Obsession) ---

@dataclass(frozen=True)
class Email:
    value: str
    def __post_init__(self):
        if "@" not in self.value:
            raise ValueError("Invalid email format")

@dataclass(frozen=True)
class PhoneNumber:
    value: str
    def __post_init__(self):
        if len(self.value) < 10:
            raise ValueError("Invalid phone number")

# --- Domain Models (Addressing D1: Data Class) ---

class CustomerRecord:
    def __init__(self, id: int, name: str, address: str, status: str):
        self.id = id
        self.name = name
        self.address = address
        self.status = status
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.notes = ""

    def update_status(self, new_status: str):
        self.status = new_status
        self.updated_at = datetime.now()

    def add_note(self, note: str):
        self.notes += f"\n{note}"

# --- Services ---

class DiscountService:
    def apply_discount(self, price: float) -> float:
        return price * 0.9  # Example logic

class PricingService:
    def __init__(self, discount_service: DiscountService):
        self.discount_service = discount_service

    def price_item(self, item_id: str) -> float:
        base_price = 100.0  # Mock logic
        return self.discount_service.apply_discount(base_price)

class CartService:
    def __init__(self, pricing_service: PricingService):
        self.pricing_service = pricing_service
        self.items = []

    def add_item(self, item_id: str):
        self.items.append(item_id)

    def get_total(self) -> float:
        return sum(self.pricing_service.price_item(i) for i in self.items)

# --- Payment Gateway (Addressing C1: Long Method) ---

class PaymentGateway:
    def __init__(self, email: Email, phone: PhoneNumber, tax_rate: float):
        self.email = email
        self.phone = phone
        self.tax_rate = tax_rate

    def process_payment(self, card_details: dict, amount: float):
        # Logic to interface with external API
        print(f"Charging {amount} to card...")
        return True

    def notify_payment(self):
        print(f"Sending notification to {self.email.value}")

    def validate_and_charge_and_notify_payment(self, card_details: dict, amount: float):
        # Refactored to delegate to single-purpose methods
        if self.process_payment(card_details, amount):
            self.notify_payment()

# --- Store Manager ---

class StoreManager:
    def __init__(self, cart: CartService, payment: PaymentGateway):
        self.cart = cart
        self.payment = payment

    def create_order(self):
        pass

    def save_invoice(self):
        pass

    def calculate_tax(self, amount: float) -> float:
        return amount * self.payment.tax_rate