from abc import ABC, abstractmethod
from datetime import date
from typing import List, Optional

# --- Domain Models ---

class Item:
    def __init__(self, id: int, title: str):
        self.id = id
        self.title = title

class Media(Item):
    def __init__(self, id: int, title: str, length: int):
        super().__init__(id, title)
        self.length = length

class Book(Media):
    def __init__(self, id: int, title: str, length: int, isbn: str):
        super().__init__(id, title, length)
        self.isbn = isbn

class Novel(Book):
    def __init__(self, id: int, title: str, length: int, isbn: str, genre: str):
        super().__init__(id, title, length, isbn)
        self.genre = genre

class Paperback(Novel):
    def __init__(self, id: int, title: str, length: int, isbn: str, genre: str, pages: int):
        super().__init__(id, title, length, isbn, genre)
        self.pages = pages

# --- Interfaces to resolve Cyclic Dependencies (D1) ---

class ICatalogService(ABC):
    @abstractmethod
    def search_catalog(self, query: str): pass
    @abstractmethod
    def reserve_book(self, book_id: int, member_id: int): pass

# --- Repositories and Services ---

class BookRepo: pass
class MemberRepo: pass
class LoanRepo: pass
class FineCalculator: pass
class Mailer: pass

# --- Refactored Loan Logic (C1) ---

class LoanService:
    """Extracted shared logic to avoid duplication in LoanDesk."""
    def register_loan(self, member_id: int, book_id: int, location: str, 
                      start_date: date, end_date: date, is_extended: bool):
        # Implementation logic for loan registration
        pass

class LoanDesk:
    def __init__(self, zip_code: str, max_retry_count: int, loan_service: LoanService):
        self.zip_code = zip_code
        self.max_retry_count = max_retry_count
        self.loan_service = loan_service

    def register_loan(self, a: int, b: int, c: str, d: date, e: date, f: bool):
        return self.loan_service.register_loan(a, b, c, d, e, f)

# --- CatalogHub (Mediator Pattern to resolve D1) ---

class CatalogHub(ICatalogService):
    def __init__(self, book_repo: BookRepo, member_repo: MemberRepo, 
                 loan_repo: LoanRepo, fine_calc: FineCalculator, mailer: Mailer):
        self.book_repo = book_repo
        self.member_repo = member_repo
        self.loan_repo = loan_repo
        self.fine_calc = fine_calc
        self.mailer = mailer

    def search_catalog(self, query: str):
        pass

    def reserve_book(self, book_id: int, member_id: int):
        pass

# --- Clients ---

class Kiosk:
    def __init__(self, catalog: ICatalogService):
        self.catalog = catalog

class MobileApp:
    def __init__(self, catalog: ICatalogService):
        self.catalog = catalog

class WebPortal:
    def __init__(self, catalog: ICatalogService):
        self.catalog = catalog

class Scanner:
    def __init__(self, catalog: ICatalogService):
        self.catalog = catalog

class ReportJob:
    def __init__(self, catalog: ICatalogService):
        self.catalog = catalog