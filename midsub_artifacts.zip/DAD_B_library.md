# Design Advisory Document
Source: designs/library.mmd

| ID | Smell | Location | Severity | Explanation | Suggested fix |
|----|-------|----------|----------|-------------|---------------|
| D1 | Cyclic Dependency | CatalogHub | high | A dependency cycle among two or more classes | Introduce an interface or mediator; invert one dependency (DIP); extract shared code |
| C1 | Duplicate Code | LoanDesk.registerLoan | low | [untrained probe] Identical method signatures or attribute sets appear across multiple unrelated classes, indicating copy-paste logic | Extract the shared members into a common base class, mixin, or utility |