# Design Advisory Document
Source: designs/notes.mmd

| ID | Smell | Location | Severity | Explanation | Suggested fix |
|----|-------|----------|----------|-------------|---------------|
| - | No smells detected | - | - | - | - |