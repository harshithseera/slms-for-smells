from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Optional

# --- Domain Models ---

@dataclass
class CustomerRecord:
    id: int
    name: str
    address: str
    status: str
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    notes: str = ""

    def update_status(self, new_status: str):
        self.status = new_status
        self.updated_at = datetime.now()

# --- Services (Addressing D1: Cyclic Dependency & C1: Duplicate Code) ---

class PricingService:
    def price_item(self, item_id: str) -> float:
        return 10.0  # Mock implementation

class DiscountService:
    def apply_discount(self, total: float) -> float:
        return total * 0.9

class CartService:
    def __init__(self, pricing_service: PricingService, discount_service: DiscountService):
        self.items: Dict[str, int] = {}
        self.pricing_service = pricing_service
        self.discount_service = discount_service

    def add_item(self, item_id: str, quantity: int):
        self.items[item_id] = self.items.get(item_id, 0) + quantity

    def remove_item(self, item_id: str):
        if item_id in self.items:
            del self.items[item_id]

    def get_total(self) -> float:
        subtotal = sum(self.pricing_service.price_item(i) * q for i, q in self.items.items())
        return self.discount_service.apply_discount(subtotal)

# --- Payment Infrastructure ---

class PaymentGateway:
    def process_payment(self, amount: float, currency: str, **kwargs) -> bool:
        # Logic for external API call
        return True

# --- Mediator/Facade (Addressing D1: Cyclic Dependency & C2: God Object) ---

class OrderManager:
    """Handles order lifecycle to prevent StoreManager from becoming a God Object."""
    def create_order(self, cart: CartService):
        pass

    def save_invoice(self, order_data: dict):
        pass

class StoreManager:
    """
    Refactored StoreManager: Acts as a coordinator rather than a monolithic class.
    Addresses D1 by removing cyclic dependencies and C2 by delegating responsibilities.
    """
    def __init__(self, payment_gateway: PaymentGateway, order_manager: OrderManager):
        self.payment_gateway = payment_gateway
        self.order_manager = order_manager

    def validate_payment(self, amount: float) -> bool:
        return self.payment_gateway.process_payment(amount, "USD")

    def find_customer(self, customer_id: int) -> Optional[CustomerRecord]:
        # Logic to fetch from DB
        return None

    def sync_inventory(self):
        pass

    def render_report(self):
        pass

# --- Example Usage ---

if __name__ == "__main__":
    # Dependency Injection
    pricing = PricingService()
    discount = DiscountService()
    cart = CartService(pricing, discount)
    
    gateway = PaymentGateway()
    orders = OrderManager()
    
    store = StoreManager(gateway, orders)
    
    cart.add_item("prod_001", 2)
    total = cart.get_total()
    
    if store.validate_payment(total):
        print("Payment successful")