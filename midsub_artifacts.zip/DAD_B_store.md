# Design Advisory Document
Source: designs/store.mmd

| ID | Smell | Location | Severity | Explanation | Suggested fix |
|----|-------|----------|----------|-------------|---------------|
| D1 | Cyclic Dependency | StoreManager | high | A dependency cycle among two or more classes | Introduce an interface or mediator; invert one dependency (DIP); extract shared code |
| D2 | Wide Hierarchy | CartService | medium | A parent class with 8 or more direct subclasses | Group subclasses under intermediate abstractions, or use Strategy/composition |
| D3 | Data Class | CustomerRecord | low | A class with attributes (6+ in training) but no behaviour | Move related behaviour into the class (Move Method) or merge it into its main user |
| C1 | Duplicate Code | CartService.addItem, CartService.removeItem, CartService.getTotal | low | [untrained probe] Identical method signatures or attribute sets appear across multiple unrelated classes, indicating copy-paste logic | Extract the shared members into a common base class, mixin, or utility |
| C2 | Duplicate Code | StoreManager.createOrder, StoreManager.updateOrder, StoreManager.deleteOrder, StoreManager.findCustomer, StoreManager.loadProduct, StoreManager.saveInvoice | low | [untrained probe] Identical method signatures or attribute sets appear across multiple unrelated classes, indicating copy-paste logic | Extract the shared members into a common base class, mixin, or utility |