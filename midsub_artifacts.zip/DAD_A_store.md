# Design Advisory Document
Source: designs/store.mmd

| ID | Smell | Location | Severity | Explanation | Suggested fix |
|----|-------|----------|----------|-------------|---------------|
| D1 | Data Class | CustomerRecord | low | A class with attributes (6+ in training) but no behaviour | Move related behaviour into the class (Move Method) or merge it into its main user |
| C1 | Long Method | PaymentGateway.validateAndChargeAndNotifyPayment | medium | Method name combines 3 or more verbs. | Split into single-purpose methods; extract helpers |
| C2 | Primitive Obsession | PaymentGateway.email, PaymentGateway.phone | low | Domain concept represented as a raw String. | Create small value classes (`Email`, `Money`, `ZipCode`) with validation |