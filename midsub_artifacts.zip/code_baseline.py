from dataclasses import dataclass, field
from datetime import date
from typing import List, Dict, Optional
from abc import ABC, abstractmethod

# --- Base Entities ---
class BaseEntity: pass

class Party(BaseEntity): pass

class Person(Party): pass

class Customer(Person):
    def __init__(self, name: str, loyalty_tier: str = "regular"):
        self.name = name
        self.loyalty_tier = loyalty_tier

class PremiumCustomer(Customer): pass

class VIPCustomer(PremiumCustomer): pass

# --- Notification System ---
class Notification(ABC):
    @abstractmethod
    def send(self, message: str): pass

class EmailNotification(Notification):
    def send(self, message: str): print(f"Email sent: {message}")

class SmsNotification(Notification):
    def send(self, message: str): print(f"SMS sent: {message}")

class PushNotification(Notification):
    def send(self, message: str): print(f"Push sent: {message}")

class WhatsAppNotification(Notification):
    def send(self, message: str): print(f"WhatsApp sent: {message}")

class SlackNotification(Notification):
    def send(self, message: str): print(f"Slack sent: {message}")

class VoiceNotification(Notification):
    def send(self, message: str): print(f"Voice call: {message}")

class PostalNotification(Notification):
    def send(self, message: str): print(f"Postal mail: {message}")

class InAppNotification(Notification):
    def send(self, message: str): print(f"In-App: {message}")

# --- Services ---
class AuditLogger:
    def log_action(self, action: str): print(f"[AUDIT] {action}")

class InventoryService:
    def reserve_stock(self, product_id: str): print(f"Reserved {product_id}")
    def release_stock(self, product_id: str): print(f"Released {product_id}")

class TaxCalculator:
    def calculate_tax(self, amount: float) -> float: return amount * 0.15

class PaymentGateway:
    def process_payment(self, amount: float, **kwargs): return True
    def validate_and_charge_and_notify_payment(self, amount: float): return True

class EmailSender:
    def send_email(self, recipient: str, body: str): print(f"Email to {recipient}: {body}")

class DiscountService:
    def apply_discount(self, amount: float, tier: str) -> float:
        return amount * 0.9 if tier == "VIP" else amount

class PricingService:
    def price_item(self, price: float) -> float: return price

class CartService:
    def __init__(self): self.items = []
    def add_item(self, item): self.items.append(item)
    def get_total(self) -> float: return sum(i['price'] for i in self.items)

# --- Core Logic ---
class OrderProcessor:
    def __init__(self, inventory: InventoryService, payment: PaymentGateway, logger: AuditLogger, tax: TaxCalculator):
        self.inventory = inventory
        self.payment = payment
        self.logger = logger
        self.tax = tax

    def process_order(self, order_data):
        self.logger.log_action("Processing order")
        self.inventory.reserve_stock("item1")
        self.payment.validate_and_charge_and_notify_payment(100.0)

class StoreManager:
    def __init__(self):
        self.inventory = InventoryService()
        self.payment = PaymentGateway()
        self.logger = AuditLogger()
        self.tax = TaxCalculator()
        self.processor = OrderProcessor(self.inventory, self.payment, self.logger, self.tax)

    def create_order(self, data): self.processor.process_order(data)
    def sync_inventory(self): pass
    def render_report(self): return "Report Data"
    def export_report(self): print("Exporting report...")

# --- Gateways ---
class CheckoutController:
    def __init__(self, processor: OrderProcessor): self.processor = processor
    def checkout(self, data): self.processor.process_order(data)

class MobileApiGateway:
    def __init__(self, processor: OrderProcessor): self.processor = processor
    def submit_order(self, data): self.processor.process_order(data)

class WebApiGateway:
    def __init__(self, processor: OrderProcessor): self.processor = processor
    def submit_order(self, data): self.processor.process_order(data)

class AdminConsole:
    def __init__(self, processor: OrderProcessor): self.processor = processor
    def create_manual_order(self, data): self.processor.process_order(data)

class BatchImporter:
    def __init__(self, processor: OrderProcessor): self.processor = processor
    def import_orders(self, orders): [self.processor.process_order(o) for o in orders]

# --- Demo ---
if __name__ == "__main__":
    manager = StoreManager()
    processor = manager.processor
    
    # Simulate checkout
    checkout = CheckoutController(processor)
    checkout.checkout({"id": 1, "total": 100})
    
    # Simulate notification
    notifier = EmailNotification()
    notifier.send("Order #1 confirmed")
    
    # Simulate report
    manager.export_report()
    
    print("System demo completed successfully.")
