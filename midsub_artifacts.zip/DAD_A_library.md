# Design Advisory Document
Source: designs/library.mmd

| ID | Smell | Location | Severity | Explanation | Suggested fix |
|----|-------|----------|----------|-------------|---------------|
| C1 | Magic Number Risk | LoanDesk.maxRetryCount | low | Business logic values should be dedicated types, not raw numbers. | Use named constants, configuration, or a dedicated type |