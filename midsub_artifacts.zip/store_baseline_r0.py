from datetime import datetime
from typing import List, Dict

class CustomerRecord:
    def __init__(self, id: int, name: str, address: str):
        self.id = id
        self.name = name
        self.address = address
        self.status = "active"
        self.createdAt = datetime.now()
        self.updatedAt = datetime.now()
        self.notes = ""

class DiscountService:
    def apply_discount(self, price: float, code: str) -> float:
        # Logic for discount application
        return price * 0.9 if code == "SAVE10" else price

class PricingService:
    def __init__(self):
        self.discount_service = DiscountService()

    def price_item(self, item_id: str, base_price: float) -> float:
        return self.discount_service.apply_discount(base_price, "NONE")

class CartService:
    def __init__(self):
        self.items: List[Dict] = []
        self.pricing_service = PricingService()

    def addItem(self, item_id: str, price: float):
        self.items.append({"id": item_id, "price": price})

    def removeItem(self, item_id: str):
        self.items = [i for i in self.items if i["id"] != item_id]

    def getTotal(self) -> float:
        return sum(item["price"] for item in self.items)

class PaymentGateway:
    def __init__(self, tax_rate: float):
        self.tax_rate = tax_rate

    def processPayment(self, cardNumber: str, expiry: str, cvv: str, amount: float, currency: str, billingAddress: str, shippingAddress: str) -> bool:
        print(f"Processing {amount} {currency} via card ending in {cardNumber[-4:]}")
        return True

    def validateAndChargeAndNotifyPayment(self, amount: float):
        print("Validating, charging, and notifying...")

class StoreManager:
    def __init__(self, store_name: str):
        self.storeName = store_name
        self.cart = CartService()
        self.payment_gateway = PaymentGateway(tax_rate=0.08)
        self.pricing_service = PricingService()

    def createOrder(self): pass
    def updateOrder(self): pass
    def deleteOrder(self): pass
    def findCustomer(self, id: int): return CustomerRecord(id, "John Doe", "123 Main St")
    def loadProduct(self): pass
    def saveInvoice(self): pass
    
    def validatePayment(self, amount: float):
        return self.payment_gateway.validateAndChargeAndNotifyPayment(amount)

    def sendNotification(self): pass
    def calculateTax(self, amount: float) -> float:
        return amount * self.payment_gateway.tax_rate

    def renderReport(self): pass
    def exportReport(self): pass
    def syncInventory(self): pass
    def archiveOrder(self): pass
    def scheduleDelivery(self): pass