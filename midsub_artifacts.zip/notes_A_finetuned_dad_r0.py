from typing import List, Optional
from datetime import datetime

class Note:
    """
    Represents a single note.
    Separates data storage logic from the domain model.
    """
    def __init__(self, title: str, body: str):
        self.title = title
        self.body = body
        self.created_at = datetime.now()

    def __repr__(self) -> str:
        return f"Note(title='{self.title}')"

class Notebook:
    """
    Manages a collection of notes.
    Handles the business logic for searching and organizing notes.
    """
    def __init__(self):
        self._notes: List[Note] = []

    def add_note(self, note: Note) -> None:
        if note not in self._notes:
            self._notes.append(note)

    def remove_note(self, note: Note) -> None:
        if note in self._notes:
            self._notes.remove(note)

    def search(self, query: str) -> List[Note]:
        """
        Searches for notes where the query matches the title or body.
        """
        query = query.lower()
        return [
            note for note in self._notes 
            if query in note.title.lower() or query in note.body.lower()
        ]

    @property
    def notes(self) -> List[Note]:
        return list(self._notes)

# Example Usage:
if __name__ == "__main__":
    notebook = Notebook()
    
    note1 = Note("Shopping List", "Milk, Eggs, Bread")
    note2 = Note("Work", "Finish the Python project")
    
    notebook.add_note(note1)
    notebook.add_note(note2)
    
    # Search functionality
    results = notebook.search("python")
    print(f"Search results: {results}")
    
    # Deletion
    notebook.remove_note(note1)
    print(f"Remaining notes: {notebook.notes}")