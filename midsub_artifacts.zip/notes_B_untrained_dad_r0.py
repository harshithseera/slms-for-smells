from typing import List, Protocol

class Note:
    """Represents a single note."""
    def __init__(self, title: str, body: str):
        self.title = title
        self.body = body

    def save(self):
        print(f"Note '{self.title}' saved.")

    def delete(self):
        print(f"Note '{self.title}' deleted.")

class NoteManager(Protocol):
    """
    Interface to break cyclic dependency (D1).
    Notebook depends on this abstraction rather than concrete Note implementation.
    """
    def save(self): ...
    def delete(self): ...

class Notebook:
    """
    Manages a collection of notes.
    Fixes D1: Decoupled from concrete Note implementation via Protocol.
    Fixes C1: Logic for note management is centralized.
    """
    def __init__(self):
        self._notes: List[Note] = []

    def _modify_note(self, note: Note, action: str):
        """Helper to centralize note operations (Fixes C1)."""
        if action == "add":
            self._notes.append(note)
            note.save()
        elif action == "remove":
            self._notes.remove(note)
            note.delete()

    def add_note(self, note: Note):
        self._modify_note(note, "add")

    def remove_note(self, note: Note):
        self._modify_note(note, "remove")

    def search(self, query: str) -> List[Note]:
        return [
            note for note in self._notes 
            if query.lower() in note.title.lower() or query.lower() in note.body.lower()
        ]

# Example Usage:
if __name__ == "__main__":
    notebook = Notebook()
    my_note = Note("Work", "Finish the Python project.")
    
    notebook.add_note(my_note)
    results = notebook.search("Python")
    print(f"Found {len(results)} note(s).")
    notebook.remove_note(my_note)