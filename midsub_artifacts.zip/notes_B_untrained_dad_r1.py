from typing import List, Protocol, runtime_checkable

@runtime_checkable
class Storable(Protocol):
    """Interface to decouple Notebook from concrete Note implementation."""
    title: str
    body: str

class Note:
    def __init__(self, title: str, body: str):
        self.title = title
        self.body = body

    def save(self):
        print(f"Note '{self.title}' saved.")

    def delete(self):
        print(f"Note '{self.title}' deleted.")

class Notebook:
    """
    Refactored to resolve D1 (Cyclic Dependency) by using a collection 
    of Storable objects rather than a direct hard dependency on Note.
    """
    def __init__(self):
        self._notes: List[Storable] = []

    def _modify_note(self, note: Storable, action: str):
        """
        Refactored to resolve C1 (Duplicate Code) by centralizing 
        the management logic for note operations.
        """
        if action == "add":
            self._notes.append(note)
        elif action == "remove":
            self._notes.remove(note)

    def add_note(self, note: Storable):
        self._modify_note(note, "add")

    def remove_note(self, note: Storable):
        self._modify_note(note, "remove")

    def search(self, query: str) -> List[Storable]:
        return [
            n for n in self._notes 
            if query.lower() in n.title.lower() or query.lower() in n.body.lower()
        ]