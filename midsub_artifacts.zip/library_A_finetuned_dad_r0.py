from dataclasses import dataclass
from datetime import date
from typing import List, Optional
from enum import Enum

# --- Constants and Configuration ---
DEFAULT_MAX_RETRY_COUNT = 3

# --- Domain Models ---
@dataclass
class Item:
    id: int
    title: str

@dataclass
class Media(Item):
    length: int

@dataclass
class Book(Media):
    isbn: str

@dataclass
class Novel(Book):
    genre: str

@dataclass
class Paperback(Novel):
    pages: int

# --- Repositories and Services (Interfaces/Stubs) ---
class BookRepo: pass
class MemberRepo: pass
class LoanRepo: pass
class FineCalculator: pass
class Mailer: pass

# --- Catalog Hub ---
class CatalogHub:
    def __init__(self, book_repo: BookRepo, member_repo: MemberRepo, 
                 loan_repo: LoanRepo, fine_calc: FineCalculator, mailer: Mailer):
        self.book_repo = book_repo
        self.member_repo = member_repo
        self.loan_repo = loan_repo
        self.fine_calc = fine_calc
        self.mailer = mailer

    def search_catalog(self, query: str): pass
    def reserve_book(self, member_id: int, book_id: int): pass

# --- Interfaces for Clients ---
class Kiosk:
    def __init__(self, hub: CatalogHub): self.hub = hub

class MobileApp:
    def __init__(self, hub: CatalogHub): self.hub = hub

class WebPortal:
    def __init__(self, hub: CatalogHub): self.hub = hub

class Scanner:
    def __init__(self, hub: CatalogHub): self.hub = hub

class ReportJob:
    def __init__(self, hub: CatalogHub): self.hub = hub

# --- Loan Desk ---
class LoanDesk:
    """
    Handles loan registration. 
    Addresses C1: Uses a named constant for retry logic instead of raw magic numbers.
    """
    def __init__(self, zip_code: str, max_retry_count: int = DEFAULT_MAX_RETRY_COUNT):
        self.zip_code = zip_code
        self.max_retry_count = max_retry_count

    def register_loan(self, 
                      member_id: int, 
                      book_id: int, 
                      location_code: str, 
                      start_date: date, 
                      due_date: date, 
                      is_extended: bool) -> bool:
        """
        Registers a loan in the system.
        """
        # Logic implementation would use self.max_retry_count here
        return True